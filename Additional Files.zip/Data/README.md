# Microsoft-Press-Introduction-to-Microsoft-Power-BI-V2

Welcome to the Microsoft Press Introduction to Microsoft Power BI Second Edition source file repository.

This directory contains all of the data files that you will need for this course.
